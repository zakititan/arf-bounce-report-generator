// rg-lib.js — Pure shared logic for the Report Generator extension (imported by background service worker and unit tests). No DOM / chrome APIs.

export const REASON_TTL_MS = 90000;
export const JIRA_DONE_TRANSITION_ID = '71';

const ACCOUNT_EMAIL_LOCAL_RE = /^[A-Za-z0-9.!#$%&'*+/=?^_`{|}~-]+$/;
const ACCOUNT_DOMAIN_RE = /^(?:[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?\.)+[A-Za-z](?:[A-Za-z0-9-]{0,60}[A-Za-z0-9])$/;
const REQUEST_ID_RE = /^[A-Za-z][A-Za-z0-9_-]{0,99}$/;

export function createUnsuspendReasonKey(requestId) {
  return 'unsuspendReason:' + (requestId || 'legacy');
}

export function buildAbuseDeskUrl(account, region, requestId) {
  return 'https://abusedesk.ops.titan.email/blocked_users.html?entity=' +
    encodeURIComponent(account) + '&region=' + region +
    (requestId ? '&rgRequestId=' + encodeURIComponent(requestId) : '');
}

// AbuseDesk status API URL for either entity type. `kind` is coerced rather
// than validated: anything that is not 'domain' falls back to the user
// endpoint so a mislabelled lookup still returns a usable reading instead of
// throwing. Accounts are validated upstream, so a non-string here is a
// programming error, while an empty one is left for the caller to reject.
export function buildAdStatusUrl(kind, account, region) {
  if (typeof account !== 'string') throw new TypeError('account must be a string');
  const scope = kind === 'domain' ? 'domains/status/?domain=' : 'users/status/?email=';
  const effectiveRegion = typeof region === 'string' && region ? region : 'us-east-1';
  return 'https://api-abusedesk.ops.titan.email/api/v1/' + scope + encodeURIComponent(account) +
    '&region=' + encodeURIComponent(effectiveRegion);
}

export function createPerAccountUnsuspendReasonKey(requestId, account) {
  return createUnsuspendReasonKey(requestId) + ':' + String(account == null ? '' : account).trim().toLowerCase();
}

export function isSafeAppsScriptUrl(value) {
  return isHttpsUrl(value, 'script.google.com', /^\/macros\//) ||
    isHttpsUrl(value, 'script.googleusercontent.com', /^\/macros\//);
}

export function persistUnsuspendReason(storageSet, getLastError, value) {
  return new Promise((resolve, reject) => {
    try {
      storageSet(value, () => {
        const error = getLastError();
        if (error) {
          reject(new Error(error.message || String(error)));
          return;
        }
        resolve();
      });
    } catch (error) {
      reject(error);
    }
  });
}

export function createUnsuspendVerifyKey(requestId, account) {
  return 'unsuspendVerify:' + (requestId || 'legacy') + ':' + encodeURIComponent(account || '');
}

function isHttpsUrl(value, hostname, pathPattern) {
  if (typeof value !== 'string') return false;
  try {
    const url = new URL(value);
    return url.protocol === 'https:' && url.hostname === hostname && pathPattern.test(url.pathname);
  } catch (_) {
    return false;
  }
}

export function isSafeJiraUrl(value) {
  return isHttpsUrl(value, 'jira.directi.com', /^\/browse\/[A-Z][A-Z0-9]+-\d+$/);
}

const JIRA_ISSUE_KEY_RE = /^[A-Z][A-Z0-9]+-\d+$/;

// Extracts a JIRA issue key from a pasted JIRA URL (browse path or
// selectedIssue query param). Returns null for anything else so callers
// fail closed instead of fetching an attacker-chosen URL.
export function extractJiraIssueKey(value) {
  if (typeof value !== 'string' || !value) return null;
  let url;
  try {
    url = new URL(value);
  } catch (_) {
    return null;
  }
  if (url.protocol !== 'https:' || url.hostname !== 'jira.directi.com') return null;
  const browse = url.pathname.match(/^\/browse\/([A-Z][A-Z0-9]+-\d+)$/);
  if (browse) return browse[1];
  const selected = url.searchParams.get('selectedIssue');
  if (selected && JIRA_ISSUE_KEY_RE.test(selected)) return selected;
  return null;
}

export function selectJiraUrl(displayed, stored) {
  if (isSafeJiraUrl(displayed)) return displayed;
  return isSafeJiraUrl(stored) ? stored : '';
}

export function isSafeGoogleSheetsUrl(value) {
  return isHttpsUrl(value, 'docs.google.com', /^\/spreadsheets\/d\/[A-Za-z0-9_-]+\/edit$/);
}

export function isAllowedWebAppOrigin(origin) {
  if (typeof origin !== 'string') return false;
  return origin === 'http://localhost:3000' ||
    origin === 'https://arf-bounce-report-generator.vercel.app' ||
    /^https:\/\/arf-bounce-report-generator-[a-z0-9-]+\.vercel\.app$/.test(origin);
}

export function isValidAccountIdentifier(value) {
  if (typeof value !== 'string' || value.length > 254) return false;
  const atIndex = value.indexOf('@');
  if (atIndex === -1) return ACCOUNT_DOMAIN_RE.test(value);
  return atIndex === value.lastIndexOf('@') &&
    atIndex > 0 && atIndex <= 64 &&
    ACCOUNT_EMAIL_LOCAL_RE.test(value.slice(0, atIndex)) &&
    ACCOUNT_DOMAIN_RE.test(value.slice(atIndex + 1));
}

export function normalizeAccountList(value) {
  const values = Array.isArray(value) ? value : typeof value === 'string' ? [value] : [];
  return values.flatMap(item => typeof item === 'string' ? item.split(',') : [])
    .map(item => item.trim()).filter(Boolean);
}

export function areValidAccountList(value) {
  const accounts = normalizeAccountList(value);
  return accounts.length > 0 && accounts.every(isValidAccountIdentifier);
}

export function validateWebAppMessage(message) {
  if (!message || typeof message !== 'object' || typeof message.type !== 'string') return false;
  const hasStrings = (keys) => keys.every(key => typeof message[key] === 'string');
  const hasRequestId = typeof message.requestId === 'string' && REQUEST_ID_RE.test(message.requestId);

  if (message.type === 'REPORT_GENERATOR_PING') return true;
  if (message.type === 'REPORT_GENERATOR_JIRA') {
    return hasRequestId && hasStrings(['panel', 'account']) &&
      (typeof message.text === 'string' || typeof message.html === 'string') &&
      Boolean(message.text || message.html) && normalizeAccountList(message.account).length === 1 &&
      isValidAccountIdentifier(message.account.trim());
  }
  if (message.type === 'REPORT_GENERATOR_UNSUSPEND' || message.type === 'REPORT_GENERATOR_UNSUSPEND_NO_JIRA') {
    const accounts = message.accounts || message.account;
    return hasRequestId && hasStrings(['panel']) && typeof message.text === 'string' &&
      typeof message.html === 'string' && areValidAccountList(accounts);
  }
  if (message.type === 'REPORT_GENERATOR_LOG_SHEET') {
    return hasRequestId && hasStrings(['date', 'zdLink', 'domainEmail', 'reportType', 'reason', 'appsScriptUrl', 'panel']);
  }
  if (message.type === 'REPORT_GENERATOR_PARTNER_PANEL_LOOKUP') {
    return hasRequestId && isValidAccountIdentifier(typeof message.account === 'string' ? message.account.trim() : '');
  }
  if (message.type === 'REPORT_GENERATOR_JIRA_DESCRIPTION') {
    return hasRequestId && hasStrings(['panel', 'jiraUrl']);
  }
  if (message.type === 'REPORT_GENERATOR_JIRA_DONE') {
    return hasRequestId && hasStrings(['panel', 'jiraUrl', 'accounts']);
  }
  if (message.type === 'REPORT_GENERATOR_RECHECK') {
    return hasRequestId && hasStrings(['panel', 'account', 'region']);
  }
  return false;
}

export function validateExtensionResult(message) {
  if (!message || typeof message !== 'object' || typeof message.type !== 'string') return false;
  if (message.requestId !== undefined &&
      (typeof message.requestId !== 'string' || !REQUEST_ID_RE.test(message.requestId))) return false;
  if (typeof message.success !== 'boolean' && message.type !== 'PARTNER_PANEL_RESULT') return false;

  if (message.type === 'REPORT_GENERATOR_JIRA_RESULT') {
    return (!message.error || typeof message.error === 'string') &&
      (!message.success || (typeof message.issueKey === 'string' && isSafeJiraUrl(message.url)));
  }
  if (message.type === 'REPORT_GENERATOR_UNSUSPEND_RESULT') {
    return (!message.issueKey || typeof message.issueKey === 'string') &&
      (!message.url || isSafeJiraUrl(message.url)) &&
      (!message.error || typeof message.error === 'string');
  }
  if (message.type === 'REPORT_GENERATOR_LOG_SHEET_RESULT') {
    return (!message.cellUrl || isSafeGoogleSheetsUrl(message.cellUrl)) &&
      (!message.unverified || typeof message.unverified === 'boolean') &&
      (!message.error || typeof message.error === 'string');
  }
  if (message.type === 'REPORT_GENERATOR_JIRA_DESCRIPTION_RESULT') {
    return (!message.issueKey || typeof message.issueKey === 'string') &&
      (!message.description || typeof message.description === 'string') &&
      (!message.summary || typeof message.summary === 'string') &&
      (!message.error || typeof message.error === 'string');
  }
  if (message.type === 'REPORT_GENERATOR_JIRA_DONE_RESULT') {
    return (!message.issueKey || typeof message.issueKey === 'string') &&
      (!message.done || typeof message.done === 'boolean') &&
      (!message.commented || typeof message.commented === 'boolean') &&
      (!message.error || typeof message.error === 'string');
  }
  if (message.type === 'REPORT_GENERATOR_RECHECK_RESULT') {
    return (!message.account || typeof message.account === 'string') &&
      (!message.outcome || typeof message.outcome === 'string') &&
      (!message.error || typeof message.error === 'string');
  }
  if (message.type === 'PARTNER_PANEL_RESULT') {
    return Boolean(message.data) && typeof message.data === 'object' &&
      typeof message.data.success === 'boolean';
  }
  return false;
}

let requestSequence = 0;
export function createRequestId(prefix, now = Date.now(), entropy = Math.random()) {
  requestSequence = (requestSequence + 1) % 1000000;
  return prefix + '-' + now.toString(36) + '-' + Math.floor(entropy * 1e9).toString(36) + '-' + requestSequence.toString(36);
}

export function createRequestContextKey(reportId, panel, requestId) {
  return JSON.stringify([reportId || '', panel || '', requestId || '']);
}

export function getScopedJiraUrl(stored, reportId, panel, requestId) {
  if (!stored || typeof stored !== 'object') return '';
  const entry = stored[createRequestContextKey(reportId, panel, requestId)];
  return entry && typeof entry.url === 'string' &&
    /^https:\/\/jira\.directi\.com\/browse\/[A-Z][A-Z0-9]+-\d+$/.test(entry.url) ? entry.url : '';
}

export function analyzeHistory(events) {
  var suspensionIdx = -1;
  var passwordResetAfterSuspension = false;
  var suspensionDate = 'N/A';
  var lastPasswordResetDate = 'N/A';

  for (var i = 0; i < events.length; i++) {
    var action = events[i].action.toLowerCase();
    if (action.indexOf('suspens') !== -1 && action.indexOf('un') === -1 && action.indexOf('removed') === -1) {
      suspensionIdx = i;
      suspensionDate = events[i].date || 'N/A';
      break;
    }
  }

  if (suspensionIdx > 0) {
    for (var j = 0; j < suspensionIdx; j++) {
      var jAction = events[j].action.toLowerCase();
      if (jAction.indexOf('password reset') !== -1 || jAction.indexOf('password changed') !== -1) {
        passwordResetAfterSuspension = true;
        break;
      }
    }
  }

  for (var k = 0; k < events.length; k++) {
    var kAction = events[k].action.toLowerCase();
    if (kAction.indexOf('password reset') !== -1 || kAction.indexOf('password changed') !== -1) {
      lastPasswordResetDate = events[k].date || 'N/A';
      break;
    }
  }

  return {
    passwordChanged: passwordResetAfterSuspension,
    suspensionDate: suspensionDate,
    lastPasswordResetDate: lastPasswordResetDate
  };
}

export function buildJiraIssueBody({ text, panel, account, zdLink }) {
  const typeLabel = panel === 'arf' ? 'ARF' : panel === 'smtpsuspend' ? 'SMTP Compromised' : 'Bounce';
  const label = panel === 'arf' ? 'ARF_unsuspension' : panel === 'smtpsuspend' ? 'SMTP_unsuspension' : 'Bounce_unsuspension';
  const summary = `${typeLabel} unsuspension request: ${account}`;

  return {
    fields: {
      project: { id: "12900" },
      issuetype: { id: "10902" },
      priority: { id: "10000" },
      summary,
      description: text,
      labels: [label],
      ...(zdLink ? { customfield_12211: zdLink } : {})
    }
  };
}

export function extractImagesRegex(html) {
  const images = [];
  const imgRegex = /<img\s+[^>]*src="(data:image\/([^;]+);base64,([^"]+))"[^>]*>/gi;
  let match;
  let index = 0;

  while ((match = imgRegex.exec(html)) !== null) {
    index++;
    const fullSrc = match[1];
    const imageType = match[2];
    const base64Data = match[3];
    const altRegex = /alt="([^"]*)"/i;
    const altMatch = altRegex.exec(match[0]);
    const altText = altMatch ? altMatch[1] : '';
    const filename = altText ? `${altText.replace(/[^a-z0-9]/gi, '_')}.png` : `screenshot-${index}.png`;

    images.push({
      base64: base64Data,
      mimeType: `image/${imageType}`,
      filename,
      dataUrl: fullSrc
    });
  }

  return images;
}

export function buildFallbackJiraUrl({ panel, account, text }) {
  const typeLabel = panel === 'arf' ? 'ARF' : panel === 'smtpsuspend' ? 'SMTP Compromised' : 'Bounce';
  const label = panel === 'arf' ? 'ARF_unsuspension' : panel === 'smtpsuspend' ? 'SMTP_unsuspension' : 'Bounce_unsuspension';
  const summary = encodeURIComponent(typeLabel + ' unsuspension request: ' + account);
  return (
    'https://jira.directi.com/secure/CreateIssueDetails!init.jspa?pid=12900&issuetype=10902&priority=10000&labels=' +
    label + '&summary=' + summary + '&description=' + encodeURIComponent((text || '').substring(0, 2000))
  );
}

export function isReasonFresh(record, now = Date.now()) {
  if (!record || typeof record.reason !== 'string' || record.reason.length === 0) return false;
  if (typeof record.ts !== 'number' || !Number.isFinite(record.ts)) return false;
  return now - record.ts <= REASON_TTL_MS;
}

// Storage safety: chrome.storage.local has a ~10MB quota and writes are never
// cleaned today. A single manual-fallback report with screenshots can exceed
// the whole quota in one write and break every later storage op — so cap what
// we store and sweep what we no longer need.
export const STORAGE_REPORT_HTML_MAX_BYTES = 500 * 1024;
export const REPORT_FALLBACK_TTL_MS = 10 * 60 * 1000;
export const JIRA_URL_TTL_MS = 24 * 60 * 60 * 1000;

export function isStorableReportHtml(html) {
  return typeof html === 'string' && html.length <= STORAGE_REPORT_HTML_MAX_BYTES;
}

function hasExpiredTs(value, field, ttlMs, now) {
  if (!value || typeof value !== 'object') return false;
  const ts = value[field];
  return typeof ts === 'number' && Number.isFinite(ts) && now - ts > ttlMs;
}

export function findStaleStorageKeys(entries, now = Date.now()) {
  const stale = [];
  if (!entries || typeof entries !== 'object') return stale;
  for (const key of Object.keys(entries)) {
    const value = entries[key];
    if (key.indexOf('unsuspendReason:') === 0) {
      if (value && typeof value === 'object' && !isReasonFresh(value, now)) stale.push(key);
    } else if (key.indexOf('unsuspendVerify:') === 0) {
      if (hasExpiredTs(value, 'ts', REASON_TTL_MS, now)) stale.push(key);
    } else if (key.indexOf('reportData:') === 0) {
      if (hasExpiredTs(value, 'timestamp', REPORT_FALLBACK_TTL_MS, now)) stale.push(key);
    } else if (key.indexOf('jiraUrl:') === 0) {
      if (hasExpiredTs(value, 'ts', JIRA_URL_TTL_MS, now)) stale.push(key);
    }
  }
  return stale;
}

export function isSuccessfulResponse(response) {
  return Boolean(response && response.ok === true);
}

export function capInlineImages(images, { maxCount = 10, maxBytesEach = 5 * 1024 * 1024, maxBytesTotal = 10 * 1024 * 1024 } = {}) {
  const list = Array.isArray(images) ? images : [];
  const kept = [];
  let keptBytes = 0;
  let droppedCount = 0;
  let droppedBytes = 0;
  for (const img of list) {
    const len = typeof img?.base64 === 'string' ? img.base64.length : 0;
    const bytes = Math.floor(len * 3 / 4);
    if (kept.length >= maxCount || bytes > maxBytesEach || keptBytes + bytes > maxBytesTotal) {
      droppedCount++;
      droppedBytes += bytes;
    } else {
      kept.push(img);
      keptBytes += bytes;
    }
  }
  return { kept, dropped: { count: droppedCount, bytes: droppedBytes } };
}

export function matchesActiveStatus(text) {
  if (typeof text !== 'string') return false;
  return /\bactive\b/.test(text.trim().toLowerCase());
}

export function createPendingMap() {
  const map = new Map();
  const check = (key) => { if (typeof key !== 'string' || key.length === 0) throw new TypeError('key must be a non-empty string'); };
  return {
    set(key, value) { check(key); map.set(key, value); },
    get(key) { check(key); return map.get(key); },
    has(key) { check(key); return map.has(key); },
    size() { return map.size; },
    resolve(key, result) {
      check(key);
      if (!map.has(key)) return false;
      const entry = map.get(key);
      map.delete(key);
      if (entry && typeof entry.resolve === 'function') entry.resolve(result);
      else if (typeof entry === 'function') entry(result);
      return true;
    },
    reject(key, err) {
      check(key);
      if (!map.has(key)) return false;
      const entry = map.get(key);
      map.delete(key);
      if (entry && typeof entry.reject === 'function') entry.reject(err);
      return true;
    }
  };
}

export function buildJiraTransitionDiscoveryUrl(jiraBase) {
  const base = typeof jiraBase === 'string' ? jiraBase.replace(/\/+$/, '') : '';
  return (issueKey) => base + '/rest/api/2/issue/' + issueKey + '/transitions';
}

export function discoverDoneTransitionId(response) {
  const list = response?.transitions;
  if (!Array.isArray(list)) return null;
  const norm = (v) => typeof v === 'string' ? v.toLowerCase() : '';
  const done = list.find((t) => norm(t?.to?.name) === 'done');
  if (done) return done.id;
  const closed = list.find((t) => norm(t?.to?.name) === 'closed');
  return closed ? closed.id : null;
}

export function isValidJiraCreatePayload({ text, html, account, panel } = {}) {
  if (typeof account !== 'string' || account.trim() === '') return false;
  if (typeof panel !== 'string' || panel.trim() === '') return false;
  if (typeof text === 'string' && text.trim() !== '') return true;
  const images = extractImagesRegex(typeof html === 'string' ? html : '');
  return images.length > 0;
}

export function buildBulkSummary(accounts) {
  const parts = Array.isArray(accounts) ? accounts : typeof accounts === 'string' ? [accounts] : [];
  const seen = new Set();
  const out = [];
  for (const item of parts) {
    if (typeof item !== 'string') continue;
    for (const piece of item.split(',')) {
      const t = piece.trim();
      if (t && !seen.has(t)) { seen.add(t); out.push(t); }
    }
  }
  return out.join(', ');
}

// Hard ceiling on every error string this module returns, so a failure reason
// can always be shown in the panel or written to a log without further work.
const AD_STATUS_ERROR_MAX_CHARS = 200;
const AD_STATUS_BODY_EXCERPT_CHARS = 120;

// Failure result with the length cap applied, so no caller can ever be handed a
// multi-megabyte "reason" by an over-long branch further down.
function unusableAdStatusBody(message) {
  return {
    json: null,
    error: message.length > AD_STATUS_ERROR_MAX_CHARS ? message.slice(0, AD_STATUS_ERROR_MAX_CHARS) : message,
  };
}

// Decides whether an AbuseDesk status response body is USABLE, from the body
// alone. The HTTP status code is deliberately ignored. Do not "fix" this back
// into an `if (!response.ok) throw` guard — that guard IS the bug.
//
// These endpoints sit behind a gunicorn reverse proxy that stamps 401 on any
// response where the browser session looks stale (`Expired: 1`,
// `Location: https://abusedesk.riva.co/login.html`), while the application
// behind the proxy still runs to completion and returns the full, valid status
// document. Captured live from the domain endpoint:
//
//   HTTP/1.1 401
//   Server: gunicorn
//   Expired: 1
//   Location: https://abusedesk.riva.co/login.html
//   {"data": [{"domain_name": "flockcloud.tech", "domain_status": "active",
//              ..., "customer_status": "active", ...}]}
//
// So `response.ok === false` while the body carries the real answer, and the
// old `if (!r.ok) throw` discarded it — every check reported a 401 failure and
// no status was ever extracted. `response.ok` is therefore meaningless here
// and carries no information this function should use.
//
// A genuine authentication failure is caught by the body instead, and it looks
// nothing like a populated document: it fails to parse (an HTML login page), or
// it parses to null/a primitive, or the extractors below find no status key in
// it. All of those return `json: null` plus a non-empty error.
//
// Objects and arrays both count as usable — /api/v1/domains/status/ returns its
// rows as an array — and the parsed payload is returned as-is, since the
// extractors read it by reference. This never throws for any input: the body is
// untrusted data off the network, and a parser that throws turns a readable
// failure into a broken check.
export function parseAdStatusBody(text) {
  if (typeof text !== 'string') {
    // typeof alone, never String(text): a hostile or throwing toString/valueOf
    // must not be able to escape from a diagnostic path.
    return unusableAdStatusBody('AbuseDesk status body must be a string, got ' + typeof text + '.');
  }
  if (text.trim() === '') {
    return unusableAdStatusBody('AbuseDesk status body was empty.');
  }

  let json;
  try {
    json = JSON.parse(text);
  } catch (_) {
    // The excerpt is truncated because this string is surfaced to users and
    // logs; a large error or login page must never ride along in full.
    const excerpt = text.length > AD_STATUS_BODY_EXCERPT_CHARS
      ? text.slice(0, AD_STATUS_BODY_EXCERPT_CHARS) + '...'
      : text;
    return unusableAdStatusBody('AbuseDesk status body is not JSON: ' + excerpt);
  }

  if (json === null) {
    return unusableAdStatusBody('AbuseDesk status body parsed to JSON null, not an object or array.');
  }
  if (typeof json !== 'object') {
    return unusableAdStatusBody('AbuseDesk status body parsed to a JSON ' + typeof json + ', not an object or array.');
  }
  return { json, error: '' };
}

// Reads a status off an already-parsed AbuseDesk payload. Only non-blank
// strings count. Where the status sits inside that payload is decided by
// readAdStatusFromPayload below, which unwraps the data/result envelopes.
function readStatusString(holder, key) {
  if (!holder || typeof holder !== 'object') return '';
  const value = holder[key];
  return typeof value === 'string' ? value.trim() : '';
}

// Shared candidate walk for the three AbuseDesk status extractors below.
//
// The endpoints do not agree on how they wrap the record, and the difference is
// not cosmetic: the user endpoint returns `data` as a single object, while
// /api/v1/domains/status/ returns `data` as an ARRAY of rows. Reading
// `json.data.domain_status` on an array is always undefined, which is why every
// domain status used to extract as '' even though the API had sent it. So when
// `data` is an array we address its first element — the endpoint returns a
// single row for the one domain asked about, and a later row is a different
// record, not a better answer.
//
// Precedence, highest first: top-level snake, top-level camel, data snake,
// data camel, result snake, result camel. Top level still wins over anything
// nested, and the whole walk is guarded so a hostile shape (or a throwing
// getter) degrades to '' instead of breaking the caller.
function readAdStatusFromPayload(json, snakeKey, camelKey) {
  try {
    if (!json || typeof json !== 'object') return '';
    const data = json.data;
    const dataFirst = Array.isArray(data) ? data[0] : data;
    const result = json.result;
    const candidates = [
      [json, snakeKey],
      [json, camelKey],
      [dataFirst, snakeKey],
      [dataFirst, camelKey],
      [result, snakeKey],
      [result, camelKey],
    ];
    for (const [holder, key] of candidates) {
      const value = readStatusString(holder, key);
      if (value) return value;
    }
    return '';
  } catch (_) {
    return '';
  }
}

// Email-entity status from the user endpoint's `user_status`.
export function extractAdUserStatus(json) {
  return readAdStatusFromPayload(json, 'user_status', 'userStatus');
}

// Domain status from the domain endpoint's `domain_status`.
export function extractAdDomainStatus(json) {
  return readAdStatusFromPayload(json, 'domain_status', 'domainStatus');
}

// Owner status for the domain. This is NOT the same key as the user
// endpoint's `user_status`: the domain row carries its own `customer_status`
// describing the domain owner's customer entity, and that row is the only place
// the domain endpoint ever reports it.
export function extractAdCustomerStatus(json) {
  return readAdStatusFromPayload(json, 'customer_status', 'customerStatus');
}

// Single status signal → 'active' | 'suspended' | 'neither'. Reuses
// matchesActiveStatus so 'inactive' (and friends) never count as active here.
function classifyStatusSignal(value) {
  if (matchesActiveStatus(value)) return 'active';
  return typeof value === 'string' && value.trim().toLowerCase().indexOf('suspend') !== -1
    ? 'suspended'
    : 'neither';
}

// Cross-checks the AbuseDesk DOM badge against the status API string. An
// active badge wins outright; a suspended badge is only overturned by an
// explicitly active API reading; anything else is unknown.
export function resolveVerifiedOutcome(input = {}) {
  if (!input || typeof input !== 'object') return 'unknown';
  const badge = classifyStatusSignal(input.badgeStatus);
  const api = classifyStatusSignal(input.apiStatus);
  if (badge === 'active') return 'confirmed';
  if (badge === 'suspended') return api === 'active' ? 'confirmed' : 'failed';
  if (api === 'active') return 'confirmed';
  if (api === 'suspended') return 'failed';
  return 'unknown';
}

// A domain is only healthy when BOTH the customer record and the domain
// record read Active, so any explicit suspension on either side is a
// definitive failure — it outranks the unknown an unreadable counterpart would
// otherwise produce. Anything short of both-active is unknown, never a guess.
export function resolveDomainOutcome(input = {}) {
  if (!input || typeof input !== 'object') return 'unknown';
  const customer = classifyStatusSignal(input.customerStatus);
  const domain = classifyStatusSignal(input.domainStatus);
  if (customer === 'suspended' || domain === 'suspended') return 'failed';
  return customer === 'active' && domain === 'active' ? 'confirmed' : 'unknown';
}
